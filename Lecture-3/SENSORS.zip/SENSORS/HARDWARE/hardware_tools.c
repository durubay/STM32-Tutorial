#include "hardware_tools.h"
#include "sys.h"

void hardware_init()
{
	//TO DO: initial the beep, HC-SR04 module and RGB module
}

void display(u8 mode)
{
	switch(mode)
	{
		case NORMAL_STATE:
			//TO DO: set the color of rgb to RED.
		  
		  break;
		case EMERGENCY_STATE:
			//TO DO: flash rgb and display the beep
		  /*for(i=0;i<3;i++)
		  {}*/
		  break;
		case ERROR_STATE:
			//TO DO: try your best
		  break;
	}
		
}
