#include "HC_SR04.h"
#include "delay.h"
#include "sys.h"
#include "usart.h"

//initial GPIO and TIM2
void HC_SR04_Init()
{
	HC_SR04_GPIO_Configuration();
  TIM2_Configuration(5000,419);
}

//initial GPIO
void HC_SR04_GPIO_Configuration()
{
	/*instantiates GPIO structure*/
  GPIO_InitTypeDef  GPIO_InitStructure;
  /*enable the clock of GPIO group*/
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
  /*echo, PB0, input port*/
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  /*trig, PB1, output port*/
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
}
//initial TIM2, arr is the period of TIM2, psc is the prescaler of TIM2
void TIM2_Configuration(u16 arr, u16 psc)
{
  TIM_TimeBaseInitTypeDef TIM_TimeBaseStructrue;
  NVIC_InitTypeDef NVIC_InitStructure;
  
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
  TIM_DeInit(TIM2);
  
  TIM_TimeBaseStructrue.TIM_Period = arr;
  TIM_TimeBaseStructrue.TIM_Prescaler = psc;
  TIM_TimeBaseStructrue.TIM_ClockDivision = TIM_CKD_DIV1;
  TIM_TimeBaseStructrue.TIM_CounterMode = TIM_CounterMode_Up;
  
  TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructrue);
  TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);
  
  NVIC_InitStructure.NVIC_IRQChannel=TIM2_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0x00;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority=0x01;
  NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
  
  NVIC_Init(&NVIC_InitStructure);
  
  TIM_Cmd(TIM2, DISABLE); 
}
//get the distance scaled by hc-sr04
int get_Diatance()
{
  int distance = 0;
  u16 TIM = 0;
  TIM_Cmd(TIM2, ENABLE);
  
  GPIO_SetBits(GPIOB, GPIO_Pin_1);
  delay_us(20);
  GPIO_ResetBits(GPIOB, GPIO_Pin_1);
 
  while((!GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0)));
  TIM2->CNT = 0;
  while(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0));
  TIM_Cmd(TIM2, DISABLE);
  
  TIM = TIM_GetCounter(TIM2);
  distance = TIM*0.85;
	//printf("%i\n",distance);
  return distance;
}

void TIM2_IRQHandler(void)
{
  if(TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
  {
    TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
  }
}
