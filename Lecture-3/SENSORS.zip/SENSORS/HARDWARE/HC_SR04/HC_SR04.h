#include "sys.h"

void HC_SR04_Init(void);
void HC_SR04_GPIO_Configuration(void);
void TIM2_Configuration(u16 arr, u16 psc);
int get_Diatance(void);
void TIM2_IRQHandler(void);
