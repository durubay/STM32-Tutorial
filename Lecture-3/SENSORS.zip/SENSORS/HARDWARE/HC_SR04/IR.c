#include "IR.h"

void IR_Configuration(void)
{
    GPIO_InitTypeDef    GPIO;
    
    //Enable APB1 Bus
    RCC_APB1PeriphClockCmd(IR_CLKLINE, ENABLE);
    
    //Register IO 
    GPIO.GPIO_Pin   = IR_PIN;
    GPIO.GPIO_Mode  = GPIO_Mode_IN;//GPIO_Mode_IPD;
	  GPIO.GPIO_PuPd = GPIO_PuPd_DOWN;
	  GPIO.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_Init(IRPORT, &GPIO);
}
