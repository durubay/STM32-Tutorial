#include "sys.h"
#include "beep.h"
#include "HC_SR04.h"
#include "rgb.h"

#define NORMAL_STATE 1
#define EMERGENCY_STATE 2
#define ERROR_STATE 3

static int i;

void hardware_init(void);
void display(u8);
