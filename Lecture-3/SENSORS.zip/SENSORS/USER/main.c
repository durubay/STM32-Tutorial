#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "hardware_tools.h"

int main(void)
{
	//initial system configuration
	//delay functions, UART and all hardwares
	delay_init(168);
	uart_init(115200);
	hardware_init();
  
  while (1)
  {
		//TO DO: get the distance between object and hc-sr04

		//TO DO: if object appears, declare a state of emergency, else delcare a state of normal. Tips: finish hardware_tools.c first.
    /*if()
    {} 
    else
    {}*/
  }
}
