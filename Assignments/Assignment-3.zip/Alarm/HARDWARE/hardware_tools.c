#include "hardware_tools.h"
#include "sys.h"

void hardware_init()
{
	BEEP_Init();         	//initial the beep
	HC_SR04_Init();       //initial HC-SR04 module
	RGB_Init();           //initial RGB module
}

void display(u8 mode)
{
	switch(mode)
	{
		case NORMAL_STATE:
			//TO DO
		  RGB_setColor(GREEN);
		  break;
		case EMERGENCY_STATE:
			//TO DO
		  for(i=0;i<3;i++)
		  {
		    RGB_flash();
		    BEEP_display();
			}
		  break;
		case ERROR_STATE:
			//TO DO
		  break;
	}
		
}
