#ifndef __HC_SR505_H__
#define	__HC_SR505_H__
#include "stm32f4xx.h"
#include "stm32f4xx_gpio.h"

#define		IR			PAin(0)
#define		IR_PIN		GPIO_Pin_0
#define		IRPORT		GPIOA
#define		IR_CLKLINE    RCC_AHB1Periph_GPIOA

void IR_Configuration(void);
#endif
