#include "delay.h"
#include "sys.h"
#include "usart.h"

#define RED 1
#define GREEN 2
#define BLUE 3

void RGB_Init(void);
void RGB_setColor(int);
void RGB_flash(void);
