#include "rgb.h"

//initial RGB LED
void RGB_Init()
{
  GPIO_InitTypeDef GPIO_InitStructure;
  
  RCC_APB1PeriphClockCmd( RCC_AHB1Periph_GPIOA , ENABLE);
  /*LED -> PA5*/
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  
	/*LED -> PA6*/
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  
	/*LED -> PA7*/
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
}
//set color of rgb led, colors include RED, GREEN and BLUE
void RGB_setColor(int color)
{
	switch(color)
	{
		case RED:
			PAout(5)=1;
		  PAout(6)=0;
		  PAout(7)=0;
		  break;
		case GREEN:
			PAout(5)=0;
		  PAout(6)=1;
		  PAout(7)=0;
		  break;
		case BLUE:
			PAout(5)=0;
		  PAout(6)=0;
		  PAout(7)=1;
		  break;
	}
}
//flash when declare the emergency state
void RGB_flash()
{
	RGB_setColor(RED);
	delay_ms(200);
	RGB_setColor(BLUE);
	delay_ms(200);
}
