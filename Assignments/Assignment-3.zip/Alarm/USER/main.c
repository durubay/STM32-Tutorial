#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "hardware_tools.h"

int main(void)
{
	//initial system configuration
	//delay functions, UART and all hardwares
	delay_init(168);
	uart_init(115200);
	hardware_init();
  
  while (1)
  {
		//get the distance between object and hc-sr04
    int diatance_Data = get_Diatance();

		//if object appears, declare a state of emergency
    if(diatance_Data<200)
    {
			display(EMERGENCY_STATE);
    }
		//else delcare a state of normal
    else
    {
			display(NORMAL_STATE);
    }
  }
}
